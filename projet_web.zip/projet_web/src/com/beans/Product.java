package com.beans;

public class Product {
	private String image;
	private String imageOption1;
	private String imageOption2;
	private String title;
	private float price;
	private int productId;
	private String description;
	
	private String style;
	private String brand;
	
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStyle() {
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getImageOption1() {
		return imageOption1;
	}
	public void setImageOption1(String imageOption1) {
		this.imageOption1 = imageOption1;
	}
	public String getImageOption2() {
		return imageOption2;
	}
	public void setImageOption2(String imageOption2) {
		this.imageOption2 = imageOption2;
	}
	
}
