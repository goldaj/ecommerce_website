package com.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.Product;

/**
 * Servlet implementation class ProductDetails
 */
@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Product p = new Product(); 
		p.setTitle(request.getParameter("title"));
		p.setBrand(request.getParameter("brand"));
		p.setDescription(request.getParameter("description"));
		p.setImage(request.getParameter("image"));
		p.setPrice(Float.valueOf(request.getParameter("price")));
		p.setProductId(Integer.valueOf(request.getParameter("productId")));
		p.setStyle(request.getParameter("style"));
		p.setImageOption1(request.getParameter("imageOption1"));
		p.setImageOption2(request.getParameter("imageOption2"));
		
		request.setAttribute("product", p);
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/product_details.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
