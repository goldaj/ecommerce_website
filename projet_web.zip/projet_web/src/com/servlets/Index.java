package com.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.Product;
import com.beans.User;

/**
 * Servlet implementation class Index
 */
@WebServlet("/Index")
public class Index extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private User usr;
	private List<Product> dashboardNewProductList;
	private List<Product> dashboardBestSellsProductList;
	private List<Product> dashboardOtherProductList;
	private List<Product> dashboardRecommandedProductList;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Index() {
        super();
        // TODO Auto-generated constructor stub
        dashboardBestSellsProductList = loadDashboardBestSellsProductListMockData();
        dashboardOtherProductList = loadDashboardOtherProductListMockData();
        dashboardRecommandedProductList = loadDashboardRecommandedProductListMockData();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Setting product list info for dashboard
		request.setAttribute("dashboardBestSellsProductList", dashboardBestSellsProductList);
		request.setAttribute("dashboardOtherProductList", dashboardOtherProductList);
		request.setAttribute("dashboardRecommandedProductList", dashboardRecommandedProductList);
		this.getServletContext().getRequestDispatcher("/WEB-INF/index.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Setting user info if existing
		usr = new User();
		usr.setTitle(request.getParameter("title"));
		usr.setEmail(request.getParameter("email"));
		usr.setFirstName(request.getParameter("firstname"));
		usr.setLastName(request.getParameter("lastname"));
		usr.setPassword(request.getParameter("password"));
		request.setAttribute("user", usr);
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/index.jsp").forward(request, response);
		//doGet(request, response);
	}

	public List<Product> loadDashboardBestSellsProductListMockData() {
		List<Product> lp = new ArrayList();
		
		Product p1 = new Product();
		p1.setTitle("Stuff1");
		p1.setPrice((float)10.0);
		p1.setImage("assets/img/a.jpg");
		lp.add(p1);
		
		Product p2 = new Product();
		p2.setTitle("Stuff2");
		p2.setPrice((float)12.0);
		p2.setImage("assets/img/b.jpg");
		lp.add(p2);
		
		Product p3 = new Product();
		p3.setTitle("Stuff3");
		p3.setPrice((float)212.0);
		p3.setImage("assets/img/c.jpg");
		lp.add(p3);
		
		Product p4 = new Product();
		p4.setTitle("Stuff4");
		p4.setPrice((float)22.0);
		p4.setImage("assets/img/d.jpg");
		lp.add(p4);
		
		Product p5 = new Product();
		p5.setTitle("Stuff5");
		p5.setPrice((float)22.87);
		p5.setImage("assets/img/e.jpg");
		lp.add(p5);
		
		Product p6 = new Product();
		p6.setTitle("Stuff6");
		p6.setPrice((float)22.0);
		p6.setImage("assets/img/f.jpg");
		lp.add(p6);
		
		Product p7 = new Product();
		p7.setTitle("Stuff7");
		p7.setPrice((float)68.0);
		p7.setImage("assets/img/g.jpg");
		lp.add(p7);
		
		Product p8 = new Product();
		p8.setTitle("Stuff8");
		p8.setPrice((float)36.50);
		p8.setImage("assets/img/h.jpg");
		lp.add(p8);
		
		return lp;
	}
	
	public List<Product> loadDashboardOtherProductListMockData() {
		List<Product> lp = new ArrayList();
		
		Product p1 = new Product();
		p1.setTitle("Stuff9");
		p1.setPrice((float)1.0);
		p1.setImage("assets/img/a.jpg");
		lp.add(p1);
		
		Product p2 = new Product();
		p2.setTitle("Stuff10");
		p2.setPrice((float)62.0);
		p2.setImage("assets/img/b.jpg");
		lp.add(p2);
		
		Product p3 = new Product();
		p3.setTitle("Stuff11");
		p3.setPrice((float)87.0);
		p3.setImage("assets/img/c.jpg");
		lp.add(p3);
		
		return lp;
	}
	
	public List<Product> loadDashboardRecommandedProductListMockData() {
		List<Product> lp = new ArrayList();
		
		Product p1 = new Product();
		p1.setTitle("Stuff12");
		p1.setPrice((float)1.0);
		p1.setImage("assets/img/a.jpg");
		lp.add(p1);
		
		Product p2 = new Product();
		p2.setTitle("Stuff13");
		p2.setPrice((float)62.0);
		p2.setImage("assets/img/b.jpg");
		lp.add(p2);
		
		Product p3 = new Product();
		p3.setTitle("Stuff14");
		p3.setPrice((float)87.0);
		p3.setImage("assets/img/c.jpg");
		lp.add(p3);
		
		return lp;
	}

	public List<Product> getDashboardNewProductList() {
		return dashboardNewProductList;
	}

	public void setDashboardNewProductList(List<Product> dashboardNewProductList) {
		this.dashboardNewProductList = dashboardNewProductList;
	}

	public List<Product> getDashboardBestSellsProductList() {
		return dashboardBestSellsProductList;
	}

	public void setDashboardBestSellsProductList(List<Product> dashboardBestSellsProductList) {
		this.dashboardBestSellsProductList = dashboardBestSellsProductList;
	}

	public List<Product> getDashboardOtherProductList() {
		return dashboardOtherProductList;
	}

	public void setDashboardOtherProductList(List<Product> dashboardOtherProductList) {
		this.dashboardOtherProductList = dashboardOtherProductList;
	}

	public List<Product> getDashboardRecommandedProductList() {
		return dashboardRecommandedProductList;
	}

	public void setDashboardRecommandedProductList(List<Product> dashboardRecommandedProductList) {
		this.dashboardRecommandedProductList = dashboardRecommandedProductList;
	}
}
