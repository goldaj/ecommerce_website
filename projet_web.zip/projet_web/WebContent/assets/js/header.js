$(document).ready(function() {'\
<!-- Header Top Section -->\
<div class="navbar navbar-inverse navbar-fixed-top">\
	<div class="topNav">\
		<div class="container" style="width:auto; margin-left:5px; margin-right:5px;">\
			<div class="alignR">\
				<div class="pull-left" style="margin-top:10px;">\
					<select style="width:100px">\
					<option><a href="#">English</a></option>\
					</select>\
					<select style="width:100px">\
					<option><a href="#">USD</a></option>\
					</select>\
					<select style="width:100px">\
					<option><a href="#">Compare</a></option>\
					</select>\
				</div>\
				<a href="index.html"> <span class="icon-home"></span> Home</a> \
				<a href="#"><span class="icon-user"></span> My Account</a> \
				<a href="#"><span class="icon-edit"></span> Wishlist </a> \
				<a href="cart.html"><span class="icon-shopping-cart"></span> My Cart (4 items)</a>\
				<a href="#"><span class="icon-edit"></span> Blog</a>\
				<!-- Logging in -->\
				<ul class="nav pull-right">\
				<li class="dropdown">\
					<a data-toggle="dropdown" class="dropdown-toggle" href="#"><span class="icon-lock"></span> Login <b class="caret"></b></a>\
					<div class="dropdown-menu">\
					<form class="form-horizontal loginFrm">\
					  <div class="control-group">\
						<input type="text" class="span2" id="inputEmail" placeholder="Email">\
					  </div>\
					  <div class="control-group">\
						<input type="password" class="span2" id="inputPassword" placeholder="Password">\
					  </div>\
					  <div class="control-group">\
						<label class="checkbox">\
						<input type="checkbox"> Remember me\
						</label>\
						<button type="submit" class="shopBtn btn-block">Sign in</button>\
					  </div>\
					</form>\
					</div>\
				</li>\
				</ul>\
				<!-- End of logging in -->\
			</div>\
		</div>\
	</div>\
</div>\
<!-- Lower Header Section -->\
<div class="container" style="width:auto">\
	<header id="header">\
		<div class="row" style="line-height:100px">\
			<!-- website logo -->\
			<a  href="index.html">\
				<img src="assets/img/page-list-cuts_10.png" style="margin:30px">\
			</a>\
			\
			<div class="pull-right" style="display:inline-block; padding-right:35px">\
				<!-- Filter item type for search -->\
				<select style="width:auto; margin-bottom:-10px; margin-right:0px">\
					<option><a href="#">All</a></option>\
				</select>\
				<!-- Searchbar -->\
				<form action="#" class="navbar-search " style="margin-left:0px">\
					<input type="text" placeholder="Search" class="search-query">\
				</form>\
				<!-- Chart link -->\
				<a  href="index.html" class="pull-right" style="margin-right:0px; margin-left:0px; margin-bottom:-10px;">\
					<img src="assets/ico/page-list-cuts_13.png" style="margin-left:0px; padding-left:0px; vertical-align: text-top;">\
				</a>\
			</div>\
		</div>\
	</header>\
<!-- Navigation Bar Section -->\
<div class="navbar">\
  <div class="navbar-inner">\
	<div class="container">\
		<ul class="nav">\
		  <li class="active"><a href="index.html">HOME	</a></li>\
		  <li class=""><a href="list-view.html">WOMEN</a></li>\
		  <li class=""><a href="list-view.html">MEN</a></li>\
		  <li class=""><a href="list-view.html">SALE</a></li>\
		  <li class=""><a href="list-view.html">ACCESSORIES</a></li>\
		  <li class=""><a href="list-view.html">VIP</a></li>\
		</ul>\
	  </div>\
	</div>\
  </div>\
</div>\
'});
